import { FormEvent, useState } from "react";
import { toast } from "sonner";
import {
  ArrowRight, Award, CalendarDays, Check, ChevronDown, Heart, Instagram, Mail, MapPin, Menu,
  PawPrint, Phone, ShieldCheck, Sparkles, Stethoscope, Star, Users, X, Youtube, Utensils, Home as HomeIcon
} from "lucide-react";

const images = {
  hero: "/manus-storage/owner-dog_68ed36ec.jpg",
  vet: "/manus-storage/vet-dog_6e37e4c5.jpg",
  grooming: "/manus-storage/grooming_2064f8c9.jpg",
  field: "/manus-storage/paws-field_1133879b.jpg",
  cuddle: "/manus-storage/cat-dog-cuddle_2537277c.jpg",
};

const services = [
  [Stethoscope, "Health checkups", "Routine wellness checks and preventive care.", "sage"],
  [Sparkles, "Grooming", "Gentle bathing, brushing and nail care.", "peach"],
  [Utensils, "Nutrition", "Personalized guidance for healthier pets.", "cream"],
  [PawPrint, "Walking & exercise", "Safe and enjoyable daily activity.", "blue"],
  [HomeIcon, "Pet sitting", "Reliable care when you’re away.", "yellow"],
  [Heart, "Wellness plans", "Personalized routines for long-term wellness.", "sage"],
] as const;

const tips = [
  ["Healthy nutrition", "Give your pet balanced nutrition suited to their needs.", images.cuddle, "WELLNESS"],
  ["Daily movement", "Regular play and activity support overall wellness.", images.field, "ACTIVITY"],
  ["Regular checkups", "Preventive care helps you stay ahead of common concerns.", images.vet, "HEALTH"],
];

const stats = [
  ["5,000+", "Happy pets", Users],
  ["10+", "Pet care services", PawPrint],
  ["98%", "Happy pet parents", Heart],
  ["5★", "Average rating", Star],
] as const;

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [sent, setSent] = useState(false);
  const go = (id: string) => { document.getElementById(id)?.scrollIntoView({ behavior: "smooth" }); setMenuOpen(false); };
  const submit = (e: FormEvent<HTMLFormElement>) => { e.preventDefault(); setSent(true); e.currentTarget.reset(); toast.success("Message sent", { description: "A PawCare teammate will be in touch soon." }); };

  return <div className="pawcare-site">
    <div className="trust-bar"><span>🐾 Caring for pets like family</span><span className="trust-separator">•</span><span>Trusted by 5,000+ pet parents</span></div>
    <header className="nav"><div className="container nav-inner">
      <button className="logo" onClick={() => go("home")}><span className="logo-icon"><PawPrint size={20} /></span><span>Paw<span>Care</span></span></button>
      <nav className={menuOpen ? "nav-links open" : "nav-links"}>
        <button onClick={() => go("home")}>Home</button><button onClick={() => go("services")}>Services</button><button onClick={() => go("about")}>About</button><button onClick={() => go("tips")}>Pet Care Tips</button><button onClick={() => go("testimonials")}>Testimonials</button><button onClick={() => go("contact")}>Contact</button>
        <button className="nav-cta" onClick={() => go("contact")}>Book a Care Session <ArrowRight size={15} /></button>
      </nav>
      <button className="menu-button" onClick={() => setMenuOpen(!menuOpen)} aria-label="Menu">{menuOpen ? <X /> : <Menu />}</button>
    </div></header>

    <main>
      <section className="hero" id="home"><div className="container hero-grid">
        <div className="hero-copy"><span className="pill"><PawPrint size={13} /> COMPLETE PET CARE</span><h1>Happy pets start with <em>better care.</em></h1><p>From everyday wellness and grooming to nutrition and personalized care, PawCare helps you give your best friend the healthy, happy life they deserve.</p><div className="hero-buttons"><button className="button button-primary" onClick={() => go("contact")}>Book a Care Session <ArrowRight size={17} /></button><button className="button button-ghost" onClick={() => go("services")}>Explore Services <ChevronDown size={16} /></button></div><div className="hero-rating"><span className="stars">★★★★★</span><span>Loved by <strong>5,000+</strong> pet parents</span></div></div>
        <div className="hero-art"><div className="hero-orb" /><div className="hero-image"><img src={images.hero} alt="Happy pet owner with a dog" /></div><div className="float-card care"><ShieldCheck size={18} /><span><b>24/7</b> Care support</span></div><div className="float-card team"><Award size={18} /><span><b>Certified</b> care team</span></div><div className="float-card happy"><Heart size={18} /><span><b>5,000+</b> happy pets</span></div><span className="hero-scribble">better care<br /><em>starts here</em> ↗</span></div>
      </div><div className="hero-bottom"><span>PERSONALIZED</span><i>✦</i><span>COMPASSIONATE</span><i>✦</i><span>TRUSTED</span><i>✦</i><span>PERSONALIZED</span></div></section>

      <section className="stats"><div className="container stats-grid">{stats.map(([value, label, Icon]) => { const StatIcon = Icon; return <div className="stat" key={label}><StatIcon size={21} /><strong>{value}</strong><span>{label}</span></div>; })}</div></section>

      <section className="section services" id="services"><div className="container"><div className="section-heading"><div><span className="eyebrow">OUR SERVICES</span><h2>Everything your pet <em>needs.</em></h2></div><p>Simple, reliable care designed around the needs of your pet.</p></div><div className="service-grid">{services.map(([Icon, title, text, tone]) => <article className={`service-card ${tone}`} key={title}><div className="service-icon"><Icon size={22} /></div><h3>{title}</h3><p>{text}</p><button onClick={() => toast(title, { description: "We’ll help you find the right care for your pet." })}>Learn More <ArrowRight size={14} /></button></article>)}</div></div></section>

      <section className="section about" id="about"><div className="container about-grid"><div className="about-image"><img src={images.grooming} alt="Dog receiving gentle grooming care" /><span className="round-note">care<br /><b>with heart</b> ✦</span></div><div className="about-copy"><span className="eyebrow">WHY PAWCARE</span><h2>Because they’re <em>family.</em></h2><p>Pets deserve compassionate, reliable and personalized care. Our team brings professional expertise and a whole lot of heart to every visit.</p><ul>{["Experienced care team", "Personalized care plans", "Safe & comfortable environment", "Easy appointment booking"].map(x => <li key={x}><span><Check size={13} /></span>{x}</li>)}</ul><button className="button button-primary" onClick={() => go("contact")}>Meet Our Care Team <ArrowRight size={16} /></button></div></div></section>

      <section className="section process"><div className="container"><div className="center-heading"><span className="eyebrow">HOW IT WORKS</span><h2>Care made <em>simple.</em></h2></div><div className="process-grid">{[["01", "Tell us about your pet", "Every pet is different. We listen first."], ["02", "Choose the right service", "Find the support that fits your routine."], ["03", "Schedule a session", "Book a time that works for both of you."], ["04", "Enjoy happier days", "We take care of the details from here."]].map(([num, title, text], i) => <div className="process-step" key={num}><span className="step-number">{num}</span><div className="step-icon">{i === 0 ? <Users /> : i === 1 ? <PawPrint /> : i === 2 ? <CalendarDays /> : <Heart />}</div><h3>{title}</h3><p>{text}</p>{i < 3 && <span className="step-line" />}</div>)}</div></div></section>

      <section className="wellness" id="tips"><div className="container wellness-grid"><div className="wellness-copy"><span className="eyebrow light">FEATURED PET WELLNESS</span><h2>Small habits.<br /><em>Big difference.</em></h2><p>Little changes add up to a longer, healthier, happier life for your best friend.</p><div className="wellness-list">{[["01", "Healthy nutrition"], ["02", "Daily movement"], ["03", "Regular checkups"]].map(([n, x]) => <div key={n}><span>{n}</span><b>{x}</b><ArrowRight size={15} /></div>)}</div><button className="button button-light" onClick={() => go("tips")}>Explore Pet Care Tips <ArrowRight size={16} /></button></div><div className="wellness-image"><img src={images.field} alt="Pets playing outdoors" /><span className="wellness-badge"><PawPrint size={17} /> happy<br />inside out</span></div></div></section>

      <section className="section tips"><div className="container"><div className="section-heading"><div><span className="eyebrow">FROM THE PAWCARE JOURNAL</span><h2>Pet care made <em>easier.</em></h2></div><button className="under-link" onClick={() => toast("More tips coming soon")}>View all tips <ArrowRight size={15} /></button></div><div className="tips-grid">{tips.map(([title, text, image, tag]) => <article className="tip-card" key={title}><div className="tip-image"><img src={image} alt={title} /></div><span className="tip-tag">{tag}</span><h3>{title}</h3><p>{text}</p><button onClick={() => toast(title, { description: "This article is being prepared by the PawCare team." })}>Read Article <ArrowRight size={14} /></button></article>)}</div></div></section>

      <section className="section testimonials" id="testimonials"><div className="container"><div className="center-heading"><span className="eyebrow">REAL PET PARENTS</span><h2>Loved by pet <em>parents.</em></h2></div><div className="testimonial-grid">{[["PawCare made taking care of my dog so much easier. The team is friendly, professional and genuinely caring.", "Sarah M.", "Milo’s human", "AM"], ["From grooming to wellness advice, everything feels thoughtful and professional.", "Arjun R.", "Bruno’s human", "AR"], ["My pet absolutely loves visiting PawCare. The experience has been wonderful.", "Priya K.", "Mochi’s human", "PK"]].map(([quote, name, role, initials], i) => <article className="testimonial" key={name}><div className="testimonial-stars">★★★★★</div><p>“{quote}”</p><div className="person"><span className={`avatar avatar-${i}`}>{initials}</span><span><b>— {name}</b><small>{role}</small></span></div></article>)}</div></div></section>

      <section className="cta"><div className="cta-paws">✦　•　✦　•　✦</div><div className="container cta-inner"><div><span className="eyebrow light">YOUR PET’S BEST LIFE STARTS HERE</span><h2>Give your pet the care<br />they <em>deserve.</em></h2><p>Start building a healthier, happier routine for your best friend today.</p></div><div className="cta-actions"><button className="button button-light" onClick={() => go("contact")}>Book a Care Session <ArrowRight size={16} /></button><button className="button button-outline-light" onClick={() => go("contact")}>Contact Us</button></div></div></section>

      <section className="section contact" id="contact"><div className="container contact-grid"><div className="contact-copy"><span className="eyebrow">GET IN TOUCH</span><h2>Let’s take care of them <em>together.</em></h2><p>Questions, bookings, or just want to say hi? Our friendly team is here.</p><div className="contact-info"><span><MapPin size={17} /><b>123 Greenleaf Lane<br /><small>Austin, TX 78701</small></b></span><span><Phone size={17} /><b>(512) 555-0124<br /><small>Mon–Fri, 8am–6pm</small></b></span><span><Mail size={17} /><b>hello@pawcare.com<br /><small>We reply within one day</small></b></span></div></div><form className="contact-form" onSubmit={submit}><div className="form-row"><label>Name<input required placeholder="Your name" /></label><label>Email<input type="email" required placeholder="you@example.com" /></label></div><div className="form-row"><label>Pet name<input required placeholder="Their name" /></label><label>Pet type<select defaultValue=""><option value="" disabled>Choose one</option><option>Dog</option><option>Cat</option><option>Other</option></select></label></div><label>Message<textarea required placeholder="How can we help?"></textarea></label><button className="button button-primary button-wide" type="submit">{sent ? "Message sent ✓" : "Send Message"} <ArrowRight size={16} /></button></form></div></section>
    </main>

    <footer className="footer"><div className="container footer-grid"><div><button className="logo footer-logo" onClick={() => go("home")}><span className="logo-icon"><PawPrint size={18} /></span><span>Paw<span>Care</span></span></button><p>Better care. Happier pets.</p></div><div><b>Company</b><button onClick={() => go("about")}>About</button><button onClick={() => go("contact")}>Our Team</button><button onClick={() => go("contact")}>Contact</button></div><div><b>Services</b><button onClick={() => go("services")}>Health Checkups</button><button onClick={() => go("services")}>Grooming</button><button onClick={() => go("services")}>Nutrition</button><button onClick={() => go("services")}>Pet Sitting</button></div><div><b>Resources</b><button onClick={() => go("tips")}>Pet Care Tips</button><button onClick={() => go("tips")}>Wellness Guide</button><button onClick={() => toast("FAQs coming soon")}>FAQs</button></div><div className="footer-social"><b>Follow along</b><span><button onClick={() => toast("Instagram link coming soon")} aria-label="Instagram"><Instagram size={16} /></button><button onClick={() => toast("YouTube link coming soon")} aria-label="Youtube"><Youtube size={16} /></button></span></div><div className="footer-bottom"><span>© 2026 PawCare. All rights reserved.</span><span>Made for pets, with love <Heart size={12} /></span></div></div></footer>
  </div>;
}
